# Third-Party Notices

Local review fixtures only; not runtime admission or distribution approval.

## Raycast Can I Use Extension

Copyright © 2021 Raycast. MIT license retained verbatim in licenses/raycast-extensions.txt. Source: https://github.com/raycast/extensions/tree/186d955eda64f9e956b25a3fdf5566b1d38f57f2/extensions/can-i-use . No extension command/source was executed.

## Can I Use Data

caniuse-lite@1.0.30001761, by Ben Briggs and contributors (as credited by package metadata), repackages Can I Use browser support data. Credit is retained for the Can I Use contributors; data source https://caniuse.com/ and https://github.com/Fyrd/caniuse ; package source https://github.com/browserslist/caniuse-lite . Licensed under Creative Commons Attribution 4.0 International: https://creativecommons.org/licenses/by/4.0/ ; full text/disclaimers retained verbatim in licenses/caniuse-lite.txt. No endorsement is implied.

Changes: data unpacked to inert JSON; defaults fixed to epoch 1777030995000; canonical target lists deduplicated/sorted; catalog/agent source order preserved via indexes; UI support flags restricted to y/a/x/u. Original notices and licenses are retained. Original data-contributor attribution still requires independent notice review before distribution.

## Support Adaptation

The support-table calculation adapts caniuse-api@3.0.0 dist/utils.js (MIT; exact source SHA-256 3383e02e76e3c04256d485fa86f86dc9495d6aee74239f936e0a7b1c50eb65b8). That package and Lodash are not executed. Copyright/permission notice retained in licenses/caniuse-api.txt.

## Dependency Licenses

- browserslist@4.28.1: exact registry archive https://registry.npmjs.org/browserslist/-/browserslist-4.28.1.tgz (SHA-256 2e3c9b9e665358cd2e9a8f1fa6a0475645ba63251b93c762d3064323a5451dd5); full retained license: licenses/browserslist.txt (original LICENSE).
- caniuse-lite@1.0.30001761: exact registry archive https://registry.npmjs.org/caniuse-lite/-/caniuse-lite-1.0.30001761.tgz (SHA-256 dad057386ae3d0178226ca938355312c16e94b6680627ec297ce1b1dcf55e2d1); full retained license: licenses/caniuse-lite.txt (original LICENSE).
- baseline-browser-mapping@2.9.11: exact registry archive https://registry.npmjs.org/baseline-browser-mapping/-/baseline-browser-mapping-2.9.11.tgz (SHA-256 f50e29a47036f22f9895de65f75172010d6b886ba4c10059d118529188a178ca); full retained license: licenses/baseline-browser-mapping.txt (original LICENSE.txt).
- electron-to-chromium@1.5.267: exact registry archive https://registry.npmjs.org/electron-to-chromium/-/electron-to-chromium-1.5.267.tgz (SHA-256 a8e9df057647f51b7a731177921184cee326f95108bf1904f4db6e30d3c9f61a); full retained license: licenses/electron-to-chromium.txt (original LICENSE).
- node-releases@2.0.27: exact registry archive https://registry.npmjs.org/node-releases/-/node-releases-2.0.27.tgz (SHA-256 7ba0a43673e36ffb18211bea5dec9a5ba1356e39417d81fa5d7468f78d1b5a85); full retained license: licenses/node-releases.txt (original LICENSE).
- caniuse-api@3.0.0: exact registry archive https://registry.npmjs.org/caniuse-api/-/caniuse-api-3.0.0.tgz (SHA-256 b85f2ba18f0ea60eb433d075ff139674201e428d2658e1eaf2bcc63c817d674d); full retained license: licenses/caniuse-api.txt (original LICENSE).

Every referenced full license is included. Fixture adaptations do not remove the source license or warranty disclaimers.
