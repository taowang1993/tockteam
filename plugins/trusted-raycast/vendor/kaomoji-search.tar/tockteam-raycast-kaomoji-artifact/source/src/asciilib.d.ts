declare module "asciilib";
