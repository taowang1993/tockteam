import React from "react";
import { Action, ActionPanel, Form, Icon, Keyboard, showToast, Toast } from "@raycast/api";
import { usePromise } from "@raycast/utils";
import { useDebouncedValue, useSelectedLanguagesSet, useTextState, usePreferences } from "./hooks";
import { LanguageCode, supportedLanguagesByCode, languages, english } from "./languages";
import { AUTO_DETECT, simpleTranslate } from "./simple-translate";
import { LanguagesManagerList } from "./LanguagesManager";
import { ConfigurableCopyPasteActions, OpenOnGoogleTranslateWebsiteAction } from "./actions";

export default function TranslateForm() {
  const [selectedLanguageSet, setSelectedLanguageSet] = useSelectedLanguagesSet();
  const langFrom = selectedLanguageSet.langFrom;
  const langTo = Array.isArray(selectedLanguageSet.langTo) ? selectedLanguageSet.langTo[0] : selectedLanguageSet.langTo;
  const { proxy } = usePreferences();
  const textInputRef = React.useRef<Form.TextArea>(null);
  const toLangInputRef = React.useRef<Form.Dropdown>(null);
  const fromLangInputRef = React.useRef<Form.Dropdown>(null);
  const setLangFrom = (l: LanguageCode) => setSelectedLanguageSet({ ...selectedLanguageSet, langFrom: l });
  const setLangTo = (l: LanguageCode) => setSelectedLanguageSet({ ...selectedLanguageSet, langTo: [l] });
  const fromLangObj = supportedLanguagesByCode[langFrom] ?? english;
  const toLangObj = supportedLanguagesByCode[langTo] ?? english;

  const [text, setText] = useTextState();
  const debouncedValue = useDebouncedValue(text, 500);
  const { data: translated, isLoading } = usePromise(
    simpleTranslate,
    [debouncedValue, { langFrom: fromLangObj.code, langTo: [toLangObj.code], proxy }],
    {
      onError(error) {
        showToast({
          style: Toast.Style.Failure,
          title: error.name,
          message: error.message,
        });
      },
    },
  );

  const handleChange = (value: string) => {
    if (value.length > 5000) {
      setText(value.slice(0, 5000));
      showToast({
        style: Toast.Style.Failure,
        title: "Limit",
        message: "Max length (5000 chars) for a single translation exceeded",
      });
    } else {
      setText(value);
    }
  };

  const autoDetectedLanguage = React.useMemo(() => {
    if (langFrom === AUTO_DETECT && translated) {
      return supportedLanguagesByCode[translated.langFrom];
    }

    return null;
  }, [translated, langFrom]);

  return (
    <Form
      isLoading={isLoading}
      actions={
        <ActionPanel>
          <ActionPanel.Section title="Generals">
            <ConfigurableCopyPasteActions defaultActionsPrefix="Translated" value={translated?.translatedText ?? ""} />
            <Action.CopyToClipboard
              title="Copy Text"
              content={text ?? ""}
              shortcut={Keyboard.Shortcut.Common.CopyName}
            />
            <Action.CopyToClipboard
              title="Copy Pronunciation"
              shortcut={Keyboard.Shortcut.Common.Pin}
              content={translated?.pronunciationText ?? ""}
            />
            <OpenOnGoogleTranslateWebsiteAction translationText={text} translation={{ langFrom, langTo }} />
            <Action.Push
              icon={Icon.Pencil}
              title="Manage Language Sets…"
              shortcut={{ macOS: { modifiers: ["cmd"], key: "l" }, Windows: { modifiers: ["ctrl"], key: "l" } }}
              target={<LanguagesManagerList />}
            />
          </ActionPanel.Section>
          <ActionPanel.Section title="Settings">
            <Action
              shortcut={{
                macOS: { modifiers: ["cmd", "shift"], key: "s" },
                Windows: { modifiers: ["ctrl", "shift"], key: "s" },
              }}
              onAction={() => {
                if (autoDetectedLanguage?.code) {
                  setSelectedLanguageSet({
                    langFrom: langTo,
                    langTo: [supportedLanguagesByCode[autoDetectedLanguage.code].code],
                  });
                } else {
                  setSelectedLanguageSet({ langFrom: langTo, langTo: [langFrom] });
                }
              }}
              title={`${autoDetectedLanguage?.name ?? fromLangObj.name} <-> ${toLangObj.name}`}
            />
            <Action
              shortcut={{
                macOS: { modifiers: ["cmd", "shift"], key: "f" },
                Windows: { modifiers: ["ctrl", "shift"], key: "f" },
              }}
              title="Change from Language"
              onAction={() => {
                fromLangInputRef.current?.focus();
              }}
            />
            <Action
              shortcut={{
                macOS: { modifiers: ["cmd", "shift"], key: "t" },
                Windows: { modifiers: ["ctrl", "shift"], key: "t" },
              }}
              title="Change to Language"
              onAction={() => {
                toLangInputRef.current?.focus();
              }}
            />
          </ActionPanel.Section>
        </ActionPanel>
      }
    >
      <Form.TextArea id="text" title="Text" value={text} onChange={handleChange} ref={textInputRef} />
      <Form.Dropdown
        id="language_from"
        title="From"
        value={autoDetectedLanguage?.code ?? langFrom}
        onChange={(v) => {
          setLangFrom(v as LanguageCode);
          textInputRef.current?.focus();
        }}
        storeValue
        ref={fromLangInputRef}
      >
        {autoDetectedLanguage && (
          <Form.Dropdown.Item value={autoDetectedLanguage.code} title={`${autoDetectedLanguage.name} (Auto-detect)`} />
        )}
        {languages.map((lang) => (
          <Form.Dropdown.Item key={lang.code} value={lang.code} title={lang.name} />
        ))}
      </Form.Dropdown>
      <Form.Dropdown
        id="language_to"
        title="To"
        value={langTo}
        onChange={(v) => {
          setLangTo(v as LanguageCode);
          textInputRef.current?.focus();
        }}
        storeValue
        ref={toLangInputRef}
      >
        {languages
          .filter((lang) => lang.code !== AUTO_DETECT)
          .map((lang) => (
            <Form.Dropdown.Item key={lang.code} value={lang.code} title={lang.name} />
          ))}
      </Form.Dropdown>
      <Form.TextArea
        id="result"
        title="Translation"
        value={translated?.translatedText ?? ""}
        placeholder="Translation"
      />
      <Form.Description title="Pronunciation" text={translated?.pronunciationText ?? ""} />
    </Form>
  );
}
